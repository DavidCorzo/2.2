import org.testng.annotations.Test;

public class test1 {
    @Test
    public void Mytest(){
        System.out.println("finally this works");
    }
}
